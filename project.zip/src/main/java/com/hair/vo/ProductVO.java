package com.hair.vo;

public class ProductVO {
	private int cno, pno, sellprice, plike;
	private String ptitle,pdetail,pimg,pdate,pthumb, pdel;
	
	
	public int getPlike() {
		return plike;
	}
	public void setPlike(int plike) {
		this.plike = plike;
	}
	public int getCno() {
		return cno;
	}
	public void setCno(int cno) {
		this.cno = cno;
	}
	public int getPno() {
		return pno;
	}
	public void setPno(int pno) {
		this.pno = pno;
	}
	public int getSellprice() {
		return sellprice;
	}
	public void setSellprice(int sellprice) {
		this.sellprice = sellprice;
	}

	public String getPtitle() {
		return ptitle;
	}
	public void setPtitle(String ptitle) {
		this.ptitle = ptitle;
	}
	public String getPdetail() {
		return pdetail;
	}
	public void setPdetail(String pdetail) {
		this.pdetail = pdetail;
	}
	public String getPimg() {
		return pimg;
	}
	public void setPimg(String pimg) {
		this.pimg = pimg;
	}
	public String getPdate() {
		return pdate;
	}
	public void setPdate(String pdate) {
		this.pdate = pdate;
	}
	public String getPthumb() {
		return pthumb;
	}
	public void setPthumb(String pthumb) {
		this.pthumb = pthumb;
	}

	public String getPdel() {
		return pdel;
	}
	public void setPdel(String pdel) {
		this.pdel = pdel;
	}
	
	
	

	
}
