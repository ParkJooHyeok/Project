package com.hair.vo;

public class CommentVO {
	private int cno, bno, cgroup, pno;
	private String cconte, cname, uid, crdate, uddate;
	public int getCno() {
		return cno;
	}
	public void setCno(int cno) {
		this.cno = cno;
	}
	public int getBno() {
		return bno;
	}
	public void setBno(int bno) {
		this.bno = bno;
	}
	public int getCgroup() {
		return cgroup;
	}
	public void setCgroup(int cgroup) {
		this.cgroup = cgroup;
	}
	public int getPno() {
		return pno;
	}
	public void setPno(int pno) {
		this.pno = pno;
	}
	public String getCconte() {
		return cconte;
	}
	public void setCconte(String cconte) {
		this.cconte = cconte;
	}
	public String getCname() {
		return cname;
	}
	public void setCname(String cname) {
		this.cname = cname;
	}
	public String getUid() {
		return uid;
	}
	public void setUid(String uid) {
		this.uid = uid;
	}
	public String getCrdate() {
		return crdate;
	}
	public void setCrdate(String crdate) {
		this.crdate = crdate;
	}
	public String getUddate() {
		return uddate;
	}
	public void setUddate(String uddate) {
		this.uddate = uddate;
	}
	
	
}
